# estoque/admin.py
from django.contrib import admin
from .models import Produto, Movimentacao, Categoria

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ('nome',)
    search_fields = ('nome',)

@admin.register(Produto)
class ProdutoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'codigo', 'categoria', 'preco', 'quantidade', 'estoque_minimo', 'estoque_baixo')
    list_filter = ('categoria',)
    search_fields = ('nome', 'codigo')
    list_editable = ('preco', 'quantidade', 'estoque_minimo')
    
    def estoque_baixo(self, obj):
        return obj.estoque_baixo
    estoque_baixo.boolean = True
    estoque_baixo.short_description = 'Estoque Baixo'

@admin.register(Movimentacao)
class MovimentacaoAdmin(admin.ModelAdmin):
    list_display = ('produto', 'get_tipo_display', 'quantidade', 'data', 'usuario')
    list_filter = ('tipo', 'data', 'usuario')
    search_fields = ('produto__nome', 'observacoes')
    date_hierarchy = 'data'