from django.contrib import admin
from django.urls import path
from estoque import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # Produtos
    path('produtos/', views.produto_list, name='produto_list'),
    path('produtos/adicionar/', views.produto_create, name='produto_create'),
    path('produtos/editar/<int:pk>/', views.produto_update, name='produto_update'),
    path('produtos/excluir/<int:pk>/', views.produto_delete, name='produto_delete'),
    path('produtos/movimentacoes/<int:pk>/', views.produto_movimentacoes, name='produto_movimentacoes'),
    
    # Movimentações
    path('movimentacoes/', views.movimentacao_list, name='movimentacao_list'),
    path('movimentacoes/adicionar/', views.movimentacao_create, name='movimentacao_create'),
    
    # Relatórios
    path('relatorios/estoque-baixo/', views.relatorio_estoque_baixo, name='relatorio_estoque_baixo'),
    path('api/valor-total-estoque/', views.valor_total_estoque, name='valor_total_estoque'),
]