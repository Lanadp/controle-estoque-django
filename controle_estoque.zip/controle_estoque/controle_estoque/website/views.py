from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.db.models import Sum, F, Q
from django.http import JsonResponse
from django.core.exceptions import ValidationError
from django.utils import timezone
from .models import Produto, Movimentacao, Categoria
from .forms import ProdutoForm, MovimentacaoForm, CategoriaForm

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def home(request):
    produtos = Produto.objects.all()
    produtos_baixo_estoque = produtos.filter(quantidade__lt=F('estoque_minimo'))
    total_estoque = produtos.aggregate(total=Sum(F('quantidade') * F('preco')))['total'] or 0
    
    context = {
        'produtos_count': produtos.count(),
        'produtos_baixo_estoque': produtos_baixo_estoque,
        'total_estoque': total_estoque,
    }
    return render(request, 'home.html', context)

@login_required
def lista_produto(request):
   
    categoria_id = request.GET.get('categoria')
    search_query = request.GET.get('search', '')
    estoque_baixo = request.GET.get('estoque_baixo') == 'on'
    
   
    produtos = Produto.objects.all()
    
    if categoria_id:
        produtos = produtos.filter(categoria_id=categoria_id)
    
    if search_query:
        produtos = produtos.filter(
            Q(nome__icontains=search_query) | 
            Q(codigo__icontains=search_query))
    
    if estoque_baixo:
        produtos = produtos.filter(quantidade__lt=F('estoque_minimo'))
    
    
    valor_total_filtrado = produtos.aggregate(
        total=Sum(F('quantidade') * F('preco')))['total'] or 0
    
    categorias = Categoria.objects.all()
    
    context = {
        'produtos': produtos,
        'categorias': categorias,
        'categoria_selecionada': int(categoria_id) if categoria_id else None,
        'search_query': search_query,
        'estoque_baixo': estoque_baixo,
        'valor_total_filtrado': valor_total_filtrado,
    }
    return render(request, 'lista_produto.html', context)

@login_required
def produto_create(request):
    if request.method == 'POST':
        form = ProdutoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_produto')
    else:
        form = ProdutoForm()
    return render(request, 'forms_produto.html', {'form': form, 'title': 'Adicionar Produto'})

@login_required
def produto_update(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    if request.method == 'POST':
        form = ProdutoForm(request.POST, instance=produto)
        if form.is_valid():
            form.save()
            return redirect('lista_produto')
    else:
        form = ProdutoForm(instance=produto)
    return render(request, 'forms_produto.html', {'form': form, 'title': 'Editar Produto'})

@login_required
def produto_delete(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    if request.method == 'POST':
        produto.delete()
        return redirect('lista_produto')
    return render(request, 'produto_confirm_delete.html', {'produto': produto})

@login_required
def movimentacao_create(request):
    if request.method == 'POST':
        form = MovimentacaoForm(request.POST, user=request.user)
        if form.is_valid():
            movimentacao = form.save(commit=False)
            movimentacao.usuario = request.user
            movimentacao.save()
            return redirect('lista_movimentacao')
    else:
        form = MovimentacaoForm(user=request.user)
    return render(request, 'forms_movimentacao.html', {'form': form})

@login_required
def movimentacao_list(request):
    produto_id = request.GET.get('produto')
    movimentacoes = Movimentacao.objects.all().order_by('-data')
    
    if produto_id:
        movimentacoes = movimentacoes.filter(produto_id=produto_id)
    
    produtos = Produto.objects.all()
    context = {
        'movimentacoes': movimentacoes,
        'produtos': produtos,
        'produto_selecionado': int(produto_id) if produto_id else None,
    }
    return render(request, 'lista_movimentacao.html', context)

@login_required
def relatorio_estoque_baixo(request):
    produtos = Produto.objects.filter(quantidade__lt=F('estoque_minimo'))
    return render(request, 'relatorio_estoque_baixo.html', {'produtos': produtos})

@login_required
def produto_movimentacoes(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    movimentacoes = produto.movimentacao_set.all().order_by('-data')
    return render(request, 'produto_movimentacoes.html', {'produto': produto, 'movimentacoes': movimentacoes})

@login_required
def valor_total_estoque(request):
   
    categoria_id = request.GET.get('categoria')
    search_query = request.GET.get('search', '')
    estoque_baixo = request.GET.get('estoque_baixo') == 'true'
    
    
    produtos = Produto.objects.all()
    
    if categoria_id:
        produtos = produtos.filter(categoria_id=categoria_id)
    
    if search_query:
        produtos = produtos.filter(
            Q(nome__icontains=search_query) | 
            Q(codigo__icontains=search_query))
    
    if estoque_baixo:
        produtos = produtos.filter(quantidade__lt=F('estoque_minimo'))
    
    
    total = produtos.aggregate(total=Sum(F('quantidade') * F('preco')))['total'] or 0
    
    return JsonResponse({
        'valor_total': total,
        'quantidade_produtos': produtos.count()
    })

@login_required
def categoria_create(request):
    if request.method == 'POST':
        form = CategoriaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_produto')
    else:
        form = CategoriaForm()
    return render(request, 'categoria_form.html', {'form': form, 'title': 'Adicionar Categoria'})